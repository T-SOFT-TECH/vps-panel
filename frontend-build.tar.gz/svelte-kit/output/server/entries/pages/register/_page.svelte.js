import { V as head } from "../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "clsx";
import "@sveltejs/kit/internal/server";
import "../../../chunks/state.svelte.js";
import { T as ThemeToggle } from "../../../chunks/ThemeToggle.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      head($$renderer3, ($$renderer4) => {
        $$renderer4.title(($$renderer5) => {
          $$renderer5.push(`<title>Create Account - VPS Panel</title>`);
        });
      });
      $$renderer3.push(`<div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 transition-colors duration-300" style="background-color: rgb(var(--bg-primary));"><div class="absolute top-6 right-6 z-20">`);
      ThemeToggle($$renderer3);
      $$renderer3.push(`<!----></div> <div class="w-full max-w-md space-y-8"><div class="text-center"><img src="/img/My Logo.png" alt="TSOFT Technologies" class="mx-auto h-20 mb-6"/> <h1 class="text-3xl font-bold mb-2" style="color: rgb(var(--text-primary));">Create Your Account</h1> <p class="text-base" style="color: rgb(var(--text-secondary));">Get started with VPS Panel</p></div> <div class="elevated-card p-8">`);
      {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="text-center py-8"><div class="relative w-16 h-16 mx-auto mb-4"><div class="absolute inset-0 rounded-full border-4" style="border-color: rgb(var(--border-primary));"></div> <div class="absolute inset-0 rounded-full border-4 border-primary-800 border-t-transparent animate-spin"></div></div> <p class="font-medium" style="color: rgb(var(--text-secondary));">Checking registration status...</p></div>`);
      }
      $$renderer3.push(`<!--]--></div> <div class="text-center"><p class="text-xs flex items-center justify-center gap-2" style="color: rgb(var(--text-tertiary));"><svg class="w-4 h-4 text-primary-800" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clip-rule="evenodd"></path></svg> Secured with enterprise-grade encryption</p></div></div></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
export {
  _page as default
};
