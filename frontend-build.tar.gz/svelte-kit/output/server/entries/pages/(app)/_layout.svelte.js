import "clsx";
import { a as authStore } from "../../../chunks/auth.svelte.js";
import "@sveltejs/kit/internal";
import "../../../chunks/exports.js";
import "../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../chunks/state.svelte.js";
import { W as ensure_array_like, X as attr, Y as attr_class, Z as attr_style, _ as stringify, $ as store_get, a0 as unsubscribe_stores } from "../../../chunks/index2.js";
import { p as page } from "../../../chunks/stores.js";
import { B as Button } from "../../../chunks/Button.js";
import { T as ThemeToggle } from "../../../chunks/ThemeToggle.js";
import { e as escape_html } from "../../../chunks/context.js";
function Navbar($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    const navigation = [
      {
        name: "Dashboard",
        href: "/dashboard",
        icon: "M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"
      },
      {
        name: "Projects",
        href: "/projects",
        icon: "M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"
      },
      {
        name: "Settings",
        href: "/settings",
        icon: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z"
      }
    ];
    function isActive(path) {
      return store_get($$store_subs ??= {}, "$page", page).url.pathname === path || store_get($$store_subs ??= {}, "$page", page).url.pathname.startsWith(path + "/");
    }
    $$renderer2.push(`<nav class="sticky top-0 z-50 modern-card border-b shadow-lg"><div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"><div class="flex justify-between h-16"><div class="flex items-center"><a href="/dashboard" class="flex items-center gap-3 group"><img src="/img/My Icon.png" alt="TSOFT Logo" class="w-10 h-10 rounded-lg shadow-md group-hover:scale-110 transition-transform duration-200"/> <span class="text-lg font-bold" style="color: rgb(var(--text-primary));">VPS Panel</span></a> <div class="hidden sm:ml-8 sm:flex sm:space-x-2"><!--[-->`);
    const each_array = ensure_array_like(navigation);
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let item = each_array[$$index];
      $$renderer2.push(`<a${attr("href", item.href)}${attr_class(`inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${stringify(isActive(item.href) ? "bg-gradient-brand text-white shadow-md" : "hover:bg-opacity-50")}`)}${attr_style(`color: ${stringify(isActive(item.href) ? "white" : "rgb(var(--text-secondary))")}`)}><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"${attr("d", item.icon)}></path></svg> ${escape_html(item.name)}</a>`);
    }
    $$renderer2.push(`<!--]--></div></div> <div class="hidden sm:flex sm:items-center sm:gap-3">`);
    ThemeToggle($$renderer2);
    $$renderer2.push(`<!----> `);
    if (authStore.user) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center gap-3 pl-3 border-l" style="border-color: rgb(var(--border-primary));"><div class="flex items-center gap-2"><div class="w-9 h-9 rounded-lg bg-gradient-brand flex items-center justify-center text-white font-semibold text-sm shadow-md">${escape_html(authStore.user.name.charAt(0).toUpperCase())}</div> <span class="text-sm font-medium" style="color: rgb(var(--text-primary));">${escape_html(authStore.user.name)}</span></div> `);
      Button($$renderer2, {
        variant: "ghost",
        size: "sm",
        onclick: () => authStore.logout(),
        children: ($$renderer3) => {
          $$renderer3.push(`<svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg> Sign out`);
        }
      });
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      Button($$renderer2, {
        variant: "primary",
        size: "sm",
        onclick: () => window.location.href = "/login",
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->Sign in`);
        }
      });
    }
    $$renderer2.push(`<!--]--></div> <div class="flex items-center sm:hidden gap-2">`);
    ThemeToggle($$renderer2);
    $$renderer2.push(`<!----> <button type="button" class="inline-flex items-center justify-center p-2 rounded-lg transition-all duration-200 hover:scale-105" style="color: rgb(var(--text-secondary));" aria-label="Toggle mobile menu">`);
    {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>`);
    }
    $$renderer2.push(`<!--]--></button></div></div></div> `);
    {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></nav>`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
function _layout($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let { children } = $$props;
    if (authStore.isAuthenticated) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="min-h-screen transition-colors duration-300" style="background-color: rgb(var(--bg-primary));">`);
      Navbar($$renderer2);
      $$renderer2.push(`<!----> <main class="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">`);
      children($$renderer2);
      $$renderer2.push(`<!----></main></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
      $$renderer2.push(`<div class="min-h-screen flex items-center justify-center transition-colors duration-300" style="background-color: rgb(var(--bg-primary));"><div class="text-center"><div class="relative w-16 h-16 mx-auto mb-4"><div class="absolute inset-0 rounded-full border-4" style="border-color: rgb(var(--border-primary));"></div> <div class="absolute inset-0 rounded-full border-4 border-primary-800 border-t-transparent animate-spin"></div></div> <p class="font-medium" style="color: rgb(var(--text-secondary));">Loading...</p></div></div>`);
    }
    $$renderer2.push(`<!--]-->`);
  });
}
export {
  _layout as default
};
