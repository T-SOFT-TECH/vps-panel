import { V as head, X as attr } from "../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../../chunks/state.svelte.js";
import { B as Button } from "../../../../chunks/Button.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let projects = [];
    let searchQuery = "";
    projects.filter((project) => project.name.toLowerCase().includes(searchQuery.toLowerCase()) || project.description?.toLowerCase().includes(searchQuery.toLowerCase()));
    head($$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Projects - VPS Panel</title>`);
      });
    });
    $$renderer2.push(`<div class="space-y-8 pb-8"><div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4"><div><h1 class="text-4xl font-bold" style="color: rgb(var(--text-primary));">Projects</h1> <p class="mt-2 text-base" style="color: rgb(var(--text-secondary));">Manage your deployed applications</p></div> `);
    Button($$renderer2, {
      onclick: () => window.location.href = "/projects/new",
      class: "btn-primary",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg class="w-5 h-5 mr-2 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg> New Project`);
      }
    });
    $$renderer2.push(`<!----></div> <div class="max-w-md"><div class="relative"><svg class="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5" style="color: rgb(var(--text-tertiary));" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg> <input type="text" placeholder="Search projects..."${attr("value", searchQuery)} class="modern-input w-full pl-12"/></div></div> `);
    {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center justify-center py-20"><div class="text-center"><div class="relative w-16 h-16 mx-auto mb-4"><div class="absolute inset-0 rounded-full border-4" style="border-color: rgb(var(--border-primary));"></div> <div class="absolute inset-0 rounded-full border-4 border-primary-800 border-t-transparent animate-spin"></div></div> <p class="font-medium" style="color: rgb(var(--text-secondary));">Loading projects...</p></div></div>`);
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
export {
  _page as default
};
