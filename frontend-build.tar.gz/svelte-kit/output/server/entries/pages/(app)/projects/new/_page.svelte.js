import { Y as attr_class, a1 as clsx, V as head, W as ensure_array_like, X as attr } from "../../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../../chunks/exports.js";
import "../../../../../chunks/utils.js";
import "@sveltejs/kit/internal/server";
import "../../../../../chunks/state.svelte.js";
import { a as api } from "../../../../../chunks/client2.js";
import { S as Select, g as gitProvidersAPI } from "../../../../../chunks/Select.js";
import { B as Button } from "../../../../../chunks/Button.js";
import { I as Input } from "../../../../../chunks/Input.js";
import { C as Card, A as Alert } from "../../../../../chunks/Alert.js";
import { e as escape_html } from "../../../../../chunks/context.js";
const projectsAPI = {
  async getAll() {
    return api.get("/projects");
  },
  async getById(id) {
    return api.get(`/projects/${id}`);
  },
  async create(data) {
    return api.post("/projects", data);
  },
  async update(id, data) {
    return api.put(`/projects/${id}`, data);
  },
  async delete(id) {
    return api.delete(`/projects/${id}`);
  },
  async detectFramework(gitUrl, gitBranch = "main", gitUsername, gitToken, rootDirectory) {
    return api.post("/projects/detect", {
      git_url: gitUrl,
      git_branch: gitBranch,
      git_username: gitUsername,
      git_token: gitToken,
      root_directory: rootDirectory
    });
  },
  async listBranches(gitUrl, gitUsername, gitToken) {
    return api.post("/projects/branches", {
      git_url: gitUrl,
      git_username: gitUsername,
      git_token: gitToken
    });
  },
  async listDirectories(gitUrl, gitBranch = "main", gitUsername, gitToken) {
    return api.post("/projects/directories", {
      git_url: gitUrl,
      git_branch: gitBranch,
      git_username: gitUsername,
      git_token: gitToken
    });
  },
  // Environment variables
  async getEnvironments(projectId) {
    return api.get(`/projects/${projectId}/environments`);
  },
  async addEnvironment(projectId, data) {
    return api.post(`/projects/${projectId}/environments`, data);
  },
  async updateEnvironment(projectId, envId, data) {
    return api.put(`/projects/${projectId}/environments/${envId}`, data);
  },
  async deleteEnvironment(projectId, envId) {
    return api.delete(`/projects/${projectId}/environments/${envId}`);
  },
  // Domains
  async getDomains(projectId) {
    return api.get(`/projects/${projectId}/domains`);
  },
  async addDomain(projectId, data) {
    return api.post(`/projects/${projectId}/domains`, data);
  },
  async updateDomain(projectId, domainId, data) {
    return api.put(`/projects/${projectId}/domains/${domainId}`, data);
  },
  async deleteDomain(projectId, domainId) {
    return api.delete(`/projects/${projectId}/domains/${domainId}`);
  }
};
function Badge($$renderer, $$props) {
  let { variant = "default", children, class: className = "" } = $$props;
  const variants = {
    success: "bg-green-950/50 text-green-400 border-green-800",
    warning: "bg-yellow-950/50 text-yellow-400 border-yellow-800",
    error: "bg-red-950/50 text-red-400 border-red-800",
    info: "bg-green-950/50 text-green-400 border-green-800",
    default: "bg-zinc-800 text-zinc-300 border-zinc-700"
  };
  const classes = `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${variants[variant]} ${className}`;
  $$renderer.push(`<span${attr_class(clsx(classes))}>`);
  children($$renderer);
  $$renderer.push(`<!----></span>`);
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let loading = false;
    let detecting = false;
    let detectionError = "";
    let providers = [];
    let repositories = [];
    let loadingRepos = false;
    let repoSearchQuery = "";
    let showRepoSelector = true;
    let selectedProvider = null;
    let name = "";
    let description = "";
    let gitUrl = "";
    let gitBranch = "main";
    let gitUsername = "";
    let gitToken = "";
    let rootDirectory = "";
    let framework = "sveltekit";
    let baasType = "";
    let buildCommand = "npm run build";
    let outputDir = "build";
    let installCommand = "npm install";
    let nodeVersion = "20";
    let frontendPort = 3e3;
    let backendPort = 8090;
    let autoDeploy = true;
    let customDomain = "";
    let branches = [];
    let loadingBranches = false;
    let showPrivateRepoFields = false;
    async function loadRepositories(providerId) {
      loadingRepos = true;
      repositories = [];
      try {
        const data = await gitProvidersAPI.listRepositories(providerId);
        repositories = data.repositories;
      } catch (err) {
        console.error("Failed to load repositories:", err);
      } finally {
        loadingRepos = false;
      }
    }
    async function handleProviderChange(providerId) {
      const provider = providers.find((p) => p.id === providerId);
      if (provider) {
        selectedProvider = provider;
        await loadRepositories(providerId);
      }
    }
    const filteredRepos = repositories.filter((repo) => repo.name.toLowerCase().includes(repoSearchQuery.toLowerCase()) || repo.full_name.toLowerCase().includes(repoSearchQuery.toLowerCase()));
    const frameworkOptions = [
      { value: "sveltekit", label: "SvelteKit" },
      { value: "react", label: "React" },
      { value: "vue", label: "Vue 3" },
      { value: "angular", label: "Angular" },
      { value: "nextjs", label: "Next.js" },
      { value: "nuxt", label: "Nuxt" }
    ];
    const baasOptions = [
      { value: "", label: "None" },
      { value: "pocketbase", label: "PocketBase" },
      { value: "supabase", label: "Supabase" },
      { value: "firebase", label: "Firebase" },
      { value: "appwrite", label: "Appwrite" }
    ];
    const nodeVersionOptions = [
      { value: "20", label: "Node.js 20" },
      { value: "18", label: "Node.js 18" },
      { value: "16", label: "Node.js 16" }
    ];
    async function loadBranches() {
      if (!gitUrl) {
        return;
      }
      loadingBranches = true;
      try {
        const result = await projectsAPI.listBranches(gitUrl, gitUsername, gitToken);
        branches = result.branches;
        if (branches.length > 0 && !branches.includes(gitBranch)) {
          gitBranch = branches[0];
        }
      } catch (err) {
        console.error("Failed to load branches:", err);
        branches = [];
      } finally {
        loadingBranches = false;
      }
    }
    async function detectFramework() {
      if (!gitUrl) {
        detectionError = "Please enter a repository URL first";
        return;
      }
      detecting = true;
      detectionError = "";
      try {
        const result = await projectsAPI.detectFramework(gitUrl, gitBranch, gitUsername || void 0, gitToken || void 0, rootDirectory || void 0);
        if (result.detected) {
          framework = result.framework;
          if (result.baas_type) {
            baasType = result.baas_type;
          }
          buildCommand = result.build_command;
          installCommand = result.install_command;
          outputDir = result.output_dir;
          nodeVersion = result.node_version;
          frontendPort = result.frontend_port;
          if (result.baas_type && result.backend_port) {
            backendPort = result.backend_port;
          }
        } else {
          detectionError = "Could not auto-detect framework. Please select manually.";
        }
      } catch (err) {
        detectionError = "Failed to analyze repository. Please check the URL and try again.";
        console.error(err);
      } finally {
        detecting = false;
      }
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      head($$renderer3, ($$renderer4) => {
        $$renderer4.title(($$renderer5) => {
          $$renderer5.push(`<title>New Project - VPS Panel</title>`);
        });
      });
      $$renderer3.push(`<div class="max-w-3xl mx-auto"><div class="mb-6"><a href="/projects" class="flex items-center text-sm" style="color: rgb(var(--text-brand));"><svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg> Back to Projects</a> <h1 class="text-3xl font-bold mt-4" style="color: rgb(var(--text-primary));">Create New Project</h1> <p class="mt-1 text-sm" style="color: rgb(var(--text-secondary));">Deploy a new application to your VPS</p></div> `);
      if (providers.length > 0 && showRepoSelector) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="mb-6">`);
        Card($$renderer3, {
          children: ($$renderer4) => {
            $$renderer4.push(`<div class="flex items-center justify-between mb-4"><div><h2 class="text-lg font-semibold" style="color: rgb(var(--text-primary));">Import Git Repository</h2> <p class="text-sm mt-1" style="color: rgb(var(--text-secondary));">Select a repository from your connected Git providers</p></div> `);
            Button($$renderer4, {
              variant: "ghost",
              size: "sm",
              onclick: () => showRepoSelector = false,
              children: ($$renderer5) => {
                $$renderer5.push(`<!---->Or enter manually →`);
              }
            });
            $$renderer4.push(`<!----></div> `);
            if (providers.length > 1) {
              $$renderer4.push("<!--[-->");
              $$renderer4.push(`<div class="mb-4"><label class="block text-sm font-medium mb-2" style="color: rgb(var(--text-primary));">Git Provider</label> `);
              $$renderer4.select(
                {
                  value: selectedProvider?.id,
                  onchange: (e) => handleProviderChange(Number(e.currentTarget.value)),
                  class: "modern-input block w-full"
                },
                ($$renderer5) => {
                  $$renderer5.push(`<!--[-->`);
                  const each_array = ensure_array_like(providers);
                  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
                    let provider = each_array[$$index];
                    $$renderer5.option({ value: provider.id }, ($$renderer6) => {
                      $$renderer6.push(`${escape_html(provider.name)} (${escape_html(provider.type)}) - @${escape_html(provider.username)}`);
                    });
                  }
                  $$renderer5.push(`<!--]-->`);
                }
              );
              $$renderer4.push(`</div>`);
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> <div class="mb-4"><input type="text" placeholder="Search repositories..."${attr("value", repoSearchQuery)} class="modern-input block w-full"/></div> `);
            if (loadingRepos) {
              $$renderer4.push("<!--[-->");
              $$renderer4.push(`<div class="text-center py-12"><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-800 mx-auto"></div> <p class="mt-4" style="color: rgb(var(--text-secondary));">Loading repositories...</p></div>`);
            } else {
              $$renderer4.push("<!--[!-->");
              if (filteredRepos.length === 0) {
                $$renderer4.push("<!--[-->");
                $$renderer4.push(`<div class="text-center py-12"><svg class="mx-auto h-12 w-12" style="color: rgb(var(--text-tertiary));" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path></svg> <p class="mt-2 text-sm" style="color: rgb(var(--text-secondary));">${escape_html("No repositories")}</p></div>`);
              } else {
                $$renderer4.push("<!--[!-->");
                $$renderer4.push(`<div class="space-y-2 max-h-96 overflow-y-auto"><!--[-->`);
                const each_array_1 = ensure_array_like(filteredRepos);
                for (let $$index_1 = 0, $$length = each_array_1.length; $$index_1 < $$length; $$index_1++) {
                  let repo = each_array_1[$$index_1];
                  $$renderer4.push(`<button type="button" class="w-full text-left p-4 rounded-lg transition-colors" style="border: 1px solid rgb(var(--border-primary)); background-color: transparent;"><div class="flex items-start justify-between"><div class="flex-1"><div class="flex items-center space-x-2"><svg class="w-5 h-5" style="color: rgb(var(--text-tertiary));" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"></path></svg> <span class="font-medium" style="color: rgb(var(--text-primary));">${escape_html(repo.name)}</span> `);
                  if (repo.private) {
                    $$renderer4.push("<!--[-->");
                    Badge($$renderer4, {
                      variant: "warning",
                      children: ($$renderer5) => {
                        $$renderer5.push(`<!---->Private`);
                      }
                    });
                  } else {
                    $$renderer4.push("<!--[!-->");
                  }
                  $$renderer4.push(`<!--]--></div> <p class="text-xs mt-1" style="color: rgb(var(--text-secondary));">${escape_html(repo.full_name)}</p></div> <svg class="w-5 h-5" style="color: rgb(var(--text-tertiary));" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg></div></button>`);
                }
                $$renderer4.push(`<!--]--></div>`);
              }
              $$renderer4.push(`<!--]-->`);
            }
            $$renderer4.push(`<!--]-->`);
          }
        });
        $$renderer3.push(`<!----></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      if (!showRepoSelector || providers.length === 0) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div>`);
        {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--> `);
        Card($$renderer3, {
          children: ($$renderer4) => {
            $$renderer4.push(`<form class="space-y-6">`);
            {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> `);
            {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> <div class="space-y-4"><h3 class="text-lg font-medium" style="color: rgb(var(--text-primary));">Basic Information</h3> `);
            Input($$renderer4, {
              label: "Project Name",
              placeholder: "my-awesome-app",
              required: true,
              disabled: loading,
              get value() {
                return name;
              },
              set value($$value) {
                name = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----> <div><label for="description" class="block text-sm font-medium mb-1" style="color: rgb(var(--text-primary));">Description</label> <textarea id="description" placeholder="A brief description of your project" rows="3"${attr("disabled", loading, true)} class="modern-input block w-full">`);
            const $$body = escape_html(description);
            if ($$body) {
              $$renderer4.push(`${$$body}`);
            }
            $$renderer4.push(`</textarea></div></div> <div class="space-y-4 pt-6" style="border-top: 1px solid rgb(var(--border-primary));"><div class="flex justify-between items-center"><h3 class="text-lg font-medium" style="color: rgb(var(--text-primary));">Git Repository</h3> <div class="flex space-x-2">`);
            Button($$renderer4, {
              variant: "secondary",
              size: "sm",
              onclick: loadBranches,
              loading: loadingBranches,
              disabled: loadingBranches || !gitUrl,
              children: ($$renderer5) => {
                $$renderer5.push(`<!---->${escape_html(loadingBranches ? "Loading..." : "Load Branches")}`);
              }
            });
            $$renderer4.push(`<!----> `);
            Button($$renderer4, {
              variant: "secondary",
              size: "sm",
              onclick: detectFramework,
              loading: detecting,
              disabled: detecting || !gitUrl,
              children: ($$renderer5) => {
                $$renderer5.push(`<!---->${escape_html(detecting ? "Detecting..." : "Auto-Detect")}`);
              }
            });
            $$renderer4.push(`<!----></div></div> `);
            if (detectionError) {
              $$renderer4.push("<!--[-->");
              Alert($$renderer4, {
                variant: "warning",
                dismissible: true,
                ondismiss: () => detectionError = "",
                children: ($$renderer5) => {
                  $$renderer5.push(`<!---->${escape_html(detectionError)}`);
                }
              });
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> `);
            Input($$renderer4, {
              label: "Repository URL",
              placeholder: "https://github.com/username/repo.git",
              required: true,
              disabled: loading,
              get value() {
                return gitUrl;
              },
              set value($$value) {
                gitUrl = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----> `);
            {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> `);
            {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> `);
            {
              $$renderer4.push("<!--[-->");
              Input($$renderer4, {
                label: "Root Directory (Optional)",
                placeholder: "e.g., frontend, client, packages/web",
                disabled: loading,
                get value() {
                  return rootDirectory;
                },
                set value($$value) {
                  rootDirectory = $$value;
                  $$settled = false;
                }
              });
              $$renderer4.push(`<!----> <p class="text-xs -mt-2" style="color: rgb(var(--text-secondary));">For monorepos, specify the subdirectory containing your app (e.g., "frontend"). Leave blank if your app is in the root.</p>`);
            }
            $$renderer4.push(`<!--]--> <div class="flex items-center mb-3"><input id="private-repo" type="checkbox"${attr("checked", showPrivateRepoFields, true)} class="h-4 w-4 rounded text-primary-800 focus:ring-primary-800" style="border-color: rgb(var(--border-primary)); background-color: rgb(var(--bg-secondary));"/> <label for="private-repo" class="ml-2 text-sm" style="color: rgb(var(--text-primary));">Private Repository (requires authentication)</label></div> `);
            {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--> `);
            if (branches.length > 0) {
              $$renderer4.push("<!--[-->");
              Select($$renderer4, {
                label: "Branch",
                options: branches.map((b) => ({ value: b, label: b })),
                disabled: loading,
                get value() {
                  return gitBranch;
                },
                set value($$value) {
                  gitBranch = $$value;
                  $$settled = false;
                }
              });
            } else {
              $$renderer4.push("<!--[!-->");
              Input($$renderer4, {
                label: "Branch",
                placeholder: "main",
                disabled: loading,
                get value() {
                  return gitBranch;
                },
                set value($$value) {
                  gitBranch = $$value;
                  $$settled = false;
                }
              });
            }
            $$renderer4.push(`<!--]--></div> <div class="space-y-4 pt-6" style="border-top: 1px solid rgb(var(--border-primary));"><h3 class="text-lg font-medium" style="color: rgb(var(--text-primary));">Framework &amp; Backend</h3> <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">`);
            Select($$renderer4, {
              label: "Framework",
              options: frameworkOptions,
              required: true,
              disabled: loading,
              get value() {
                return framework;
              },
              set value($$value) {
                framework = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----> `);
            Select($$renderer4, {
              label: "Backend/BaaS",
              options: baasOptions,
              disabled: loading,
              get value() {
                return baasType;
              },
              set value($$value) {
                baasType = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----></div> `);
            if (baasType === "pocketbase") {
              $$renderer4.push("<!--[-->");
              $$renderer4.push(`<div class="p-4 rounded-lg" style="background-color: rgb(var(--bg-secondary)); border-left: 3px solid rgb(10, 101, 34);"><div class="flex items-start space-x-3"><svg class="w-5 h-5 mt-0.5 flex-shrink-0" style="color: rgb(10, 101, 34);" fill="currentColor" viewBox="0 0 24 24"><path d="M13 9h-2V7h2m0 10h-2v-6h2m-1-9A10 10 0 0 0 2 12a10 10 0 0 0 10 10 10 10 0 0 0 10-10A10 10 0 0 0 12 2z"></path></svg> <div class="flex-1"><p class="text-sm font-medium mb-1" style="color: rgb(var(--text-primary));">PocketBase Backend</p> <p class="text-xs" style="color: rgb(var(--text-secondary));">PocketBase will be automatically deployed alongside your frontend using the <strong>official binary from GitHub</strong>.
									Your deployment will include:</p> <ul class="text-xs mt-2 space-y-1 ml-4" style="color: rgb(var(--text-secondary));"><li>• SQLite database with realtime subscriptions</li> <li>• Built-in authentication and file storage</li> <li>• Admin dashboard at <code class="px-1 py-0.5 rounded" style="background-color: rgb(var(--bg-primary)); color: rgb(var(--text-brand));">/_</code></li> <li>• REST and Realtime APIs at <code class="px-1 py-0.5 rounded" style="background-color: rgb(var(--bg-primary)); color: rgb(var(--text-brand));">/api/*</code></li></ul></div></div></div>`);
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--></div> <div class="space-y-4 pt-6" style="border-top: 1px solid rgb(var(--border-primary));"><h3 class="text-lg font-medium" style="color: rgb(var(--text-primary));">Build Configuration</h3> <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">`);
            Input($$renderer4, {
              label: "Install Command",
              placeholder: "npm install",
              disabled: loading,
              get value() {
                return installCommand;
              },
              set value($$value) {
                installCommand = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----> `);
            Input($$renderer4, {
              label: "Build Command",
              placeholder: "npm run build",
              disabled: loading,
              get value() {
                return buildCommand;
              },
              set value($$value) {
                buildCommand = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----> `);
            Input($$renderer4, {
              label: "Output Directory",
              placeholder: "build",
              disabled: loading,
              get value() {
                return outputDir;
              },
              set value($$value) {
                outputDir = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----> `);
            Select($$renderer4, {
              label: "Node Version",
              options: nodeVersionOptions,
              disabled: loading,
              get value() {
                return nodeVersion;
              },
              set value($$value) {
                nodeVersion = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----></div></div> <div class="space-y-4 pt-6" style="border-top: 1px solid rgb(var(--border-primary));"><h3 class="text-lg font-medium" style="color: rgb(var(--text-primary));">Port Configuration</h3> <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">`);
            Input($$renderer4, {
              label: "Frontend Port",
              type: "number",
              placeholder: "3000",
              disabled: loading,
              get value() {
                return frontendPort;
              },
              set value($$value) {
                frontendPort = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----> `);
            if (baasType) {
              $$renderer4.push("<!--[-->");
              Input($$renderer4, {
                label: "Backend Port",
                type: "number",
                placeholder: "8090",
                disabled: loading,
                get value() {
                  return backendPort;
                },
                set value($$value) {
                  backendPort = $$value;
                  $$settled = false;
                }
              });
            } else {
              $$renderer4.push("<!--[!-->");
            }
            $$renderer4.push(`<!--]--></div></div> <div class="space-y-4 pt-6" style="border-top: 1px solid rgb(var(--border-primary));"><h3 class="text-lg font-medium" style="color: rgb(var(--text-primary));">Domain (Optional)</h3> `);
            Input($$renderer4, {
              label: "Custom Domain",
              placeholder: "myapp.example.com",
              disabled: loading,
              get value() {
                return customDomain;
              },
              set value($$value) {
                customDomain = $$value;
                $$settled = false;
              }
            });
            $$renderer4.push(`<!----> <p class="text-xs -mt-2" style="color: rgb(var(--text-secondary));">Leave blank to auto-generate a subdomain (e.g., myapp-1.panel.yourdomain.com)</p></div> <div class="pt-6" style="border-top: 1px solid rgb(var(--border-primary));"><div class="flex items-start"><div class="flex items-center h-5"><input id="auto-deploy" type="checkbox"${attr("checked", autoDeploy, true)}${attr("disabled", loading, true)} class="h-4 w-4 rounded text-primary-800 focus:ring-primary-800" style="border-color: rgb(var(--border-primary)); background-color: rgb(var(--bg-secondary));"/></div> <div class="ml-3 text-sm"><label for="auto-deploy" class="font-medium" style="color: rgb(var(--text-primary));">Auto Deploy</label> <p style="color: rgb(var(--text-secondary));">Automatically deploy when changes are pushed to the repository</p></div></div></div> <div class="flex justify-end space-x-3 pt-6" style="border-top: 1px solid rgb(var(--border-primary));">`);
            Button($$renderer4, {
              variant: "ghost",
              onclick: () => window.history.back(),
              disabled: loading,
              children: ($$renderer5) => {
                $$renderer5.push(`<!---->Cancel`);
              }
            });
            $$renderer4.push(`<!----> `);
            Button($$renderer4, {
              type: "submit",
              loading,
              disabled: loading,
              children: ($$renderer5) => {
                $$renderer5.push(`<!---->${escape_html("Create Project")}`);
              }
            });
            $$renderer4.push(`<!----></div></form>`);
          }
        });
        $$renderer3.push(`<!----></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--></div>`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
export {
  _page as default
};
