import { $ as store_get, V as head, a0 as unsubscribe_stores } from "../../../../../../../chunks/index2.js";
import { a as ssr_context, e as escape_html } from "../../../../../../../chunks/context.js";
import { p as page } from "../../../../../../../chunks/stores.js";
import "@sveltejs/kit/internal";
import "../../../../../../../chunks/exports.js";
import "../../../../../../../chunks/utils.js";
import "clsx";
import "@sveltejs/kit/internal/server";
import "../../../../../../../chunks/state.svelte.js";
function onDestroy(fn) {
  /** @type {SSRContext} */
  ssr_context.r.on_destroy(fn);
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    var $$store_subs;
    Number(store_get($$store_subs ??= {}, "$page", page).params.id);
    const deploymentId = Number(store_get($$store_subs ??= {}, "$page", page).params.deploymentId);
    onDestroy(() => {
    });
    head($$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Deployment #${escape_html(deploymentId)} - VPS Panel</title>`);
      });
    });
    {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="text-center py-12"><div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-800 mx-auto"></div> <p class="mt-4" style="color: rgb(var(--text-secondary));">Loading deployment...</p></div>`);
    }
    $$renderer2.push(`<!--]-->`);
    if ($$store_subs) unsubscribe_stores($$store_subs);
  });
}
export {
  _page as default
};
