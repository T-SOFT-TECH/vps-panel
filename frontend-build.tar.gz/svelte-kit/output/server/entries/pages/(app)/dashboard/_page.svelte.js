import { V as head } from "../../../../chunks/index2.js";
import "@sveltejs/kit/internal";
import "../../../../chunks/exports.js";
import "../../../../chunks/utils.js";
import "clsx";
import "@sveltejs/kit/internal/server";
import "../../../../chunks/state.svelte.js";
import { B as Button } from "../../../../chunks/Button.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    head($$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Dashboard - VPS Panel</title>`);
      });
    });
    $$renderer2.push(`<div class="space-y-8 pb-8"><div class="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4"><div><h1 class="text-4xl font-bold" style="color: rgb(var(--text-primary));">Dashboard</h1> <p class="mt-2 text-base" style="color: rgb(var(--text-secondary));">Overview of your projects and deployments</p></div> `);
    Button($$renderer2, {
      onclick: () => window.location.href = "/projects/new",
      class: "btn-primary",
      children: ($$renderer3) => {
        $$renderer3.push(`<svg class="w-5 h-5 mr-2 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg> New Project`);
      }
    });
    $$renderer2.push(`<!----></div> `);
    {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div class="flex items-center justify-center py-20"><div class="text-center"><div class="relative w-16 h-16 mx-auto mb-4"><div class="absolute inset-0 rounded-full border-4" style="border-color: rgb(var(--border-primary));"></div> <div class="absolute inset-0 rounded-full border-4 border-primary-800 border-t-transparent animate-spin"></div></div> <p class="font-medium" style="color: rgb(var(--text-secondary));">Loading dashboard...</p></div></div>`);
    }
    $$renderer2.push(`<!--]--></div>`);
  });
}
export {
  _page as default
};
