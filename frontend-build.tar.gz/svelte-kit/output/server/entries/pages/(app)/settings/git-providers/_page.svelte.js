import { V as head, W as ensure_array_like, Z as attr_style, X as attr } from "../../../../../chunks/index2.js";
import { g as gitProvidersAPI, S as Select } from "../../../../../chunks/Select.js";
import { B as Button } from "../../../../../chunks/Button.js";
import { C as Card, A as Alert } from "../../../../../chunks/Alert.js";
import { I as Input } from "../../../../../chunks/Input.js";
import { e as escape_html } from "../../../../../chunks/context.js";
function html(value) {
  var html2 = String(value ?? "");
  var open = "<!---->";
  return open + html2 + "<!---->";
}
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let providers = [];
    let loading = false;
    let error = "";
    let success = "";
    let showModal = false;
    let editingProvider = null;
    let modalLoading = false;
    let providerType = "github";
    let providerName = "";
    let providerUrl = "";
    let clientId = "";
    let clientSecret = "";
    let isDefault = false;
    let callbackUrl = typeof window !== "undefined" ? `${window.location.origin}/api/v1/auth/oauth/callback/${providerType}` : "";
    const providerTypeOptions = [
      { value: "github", label: "GitHub" },
      { value: "gitea", label: "Gitea (Self-hosted)" },
      {
        value: "gitlab",
        label: "GitLab (Coming Soon)",
        disabled: true
      }
    ];
    async function loadProviders() {
      loading = true;
      try {
        const data = await gitProvidersAPI.getAll();
        providers = data.providers || [];
      } catch (err) {
        error = "Failed to load providers";
        console.error(err);
      } finally {
        loading = false;
      }
    }
    function openAddModal() {
      editingProvider = null;
      providerType = "github";
      providerName = "";
      providerUrl = "";
      clientId = "";
      clientSecret = "";
      isDefault = false;
      showModal = true;
    }
    function openEditModal(provider) {
      editingProvider = provider;
      providerType = provider.type;
      providerName = provider.name;
      providerUrl = provider.url || "";
      clientId = "";
      clientSecret = "";
      isDefault = provider.is_default;
      showModal = true;
    }
    async function handleDelete(provider) {
      if (!confirm(`Are you sure you want to delete "${provider.name}"?`)) {
        return;
      }
      try {
        await gitProvidersAPI.delete(provider.id);
        success = "Provider deleted successfully";
        await loadProviders();
      } catch (err) {
        error = err.message || "Failed to delete provider";
      }
    }
    async function handleConnect(provider) {
      try {
        const { url } = await gitProvidersAPI.initiateOAuth(provider.id);
        window.location.href = url;
      } catch (err) {
        error = err.message || "Failed to initiate OAuth";
      }
    }
    async function handleDisconnect(provider) {
      if (!confirm(`Disconnect ${provider.name}?`)) {
        return;
      }
      try {
        await gitProvidersAPI.disconnect(provider.id);
        success = "Provider disconnected successfully";
        await loadProviders();
      } catch (err) {
        error = err.message || "Failed to disconnect provider";
      }
    }
    function getProviderIcon(type) {
      switch (type) {
        case "github":
          return `<path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>`;
        case "gitea":
          return `<path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"/>`;
        case "gitlab":
          return `<path d="M23.955 13.587l-1.342-4.135-2.664-8.189a.455.455 0 0 0-.867 0L16.418 9.45H7.582L4.919 1.263a.455.455 0 0 0-.867 0L1.388 9.452.046 13.587a.924.924 0 0 0 .331 1.023L12 23.054l11.623-8.443a.92.92 0 0 0 .332-1.024"/>`;
        default:
          return "";
      }
    }
    function getProviderColor(type) {
      switch (type) {
        case "github":
          return "color: rgb(var(--text-primary));";
        case "gitea":
          return "color: #0a6522;";
        case "gitlab":
          return "color: #ff6b35;";
        default:
          return "color: rgb(var(--text-tertiary));";
      }
    }
    let $$settled = true;
    let $$inner_renderer;
    function $$render_inner($$renderer3) {
      head($$renderer3, ($$renderer4) => {
        $$renderer4.title(($$renderer5) => {
          $$renderer5.push(`<title>Git Providers - VPS Panel</title>`);
        });
      });
      $$renderer3.push(`<div class="max-w-6xl mx-auto"><div class="mb-6 flex items-center justify-between"><div><h1 class="text-3xl font-bold" style="color: rgb(var(--text-primary));">Git Providers</h1> <p class="mt-1 text-sm" style="color: rgb(var(--text-tertiary));">Manage your Git OAuth providers for seamless repository integration</p></div> `);
      Button($$renderer3, {
        onclick: openAddModal,
        children: ($$renderer4) => {
          $$renderer4.push(`<!---->Add Provider`);
        }
      });
      $$renderer3.push(`<!----></div> `);
      if (error) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="mb-4">`);
        Alert($$renderer3, {
          variant: "error",
          dismissible: true,
          ondismiss: () => error = "",
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->${escape_html(error)}`);
          }
        });
        $$renderer3.push(`<!----></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      if (success) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="mb-4">`);
        Alert($$renderer3, {
          variant: "success",
          dismissible: true,
          ondismiss: () => success = "",
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->${escape_html(success)}`);
          }
        });
        $$renderer3.push(`<!----></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]--> `);
      if (loading) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="text-center py-12"><div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-800 mx-auto"></div> <p class="mt-4" style="color: rgb(var(--text-tertiary));">Loading providers...</p></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
        if (providers.length === 0) {
          $$renderer3.push("<!--[-->");
          Card($$renderer3, {
            children: ($$renderer4) => {
              $$renderer4.push(`<div class="text-center py-12"><svg class="mx-auto h-12 w-12" style="color: rgb(var(--text-tertiary));" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"></path></svg> <h3 class="mt-2 text-sm font-medium" style="color: rgb(var(--text-primary));">No Git providers</h3> <p class="mt-1 text-sm" style="color: rgb(var(--text-tertiary));">Get started by adding your first Git provider.</p> <div class="mt-6">`);
              Button($$renderer4, {
                onclick: openAddModal,
                children: ($$renderer5) => {
                  $$renderer5.push(`<!---->Add Provider`);
                }
              });
              $$renderer4.push(`<!----></div></div>`);
            }
          });
        } else {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<div class="grid grid-cols-1 md:grid-cols-2 gap-4"><!--[-->`);
          const each_array = ensure_array_like(providers);
          for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
            let provider = each_array[$$index];
            $$renderer3.push(`<div>`);
            Card($$renderer3, {
              children: ($$renderer4) => {
                $$renderer4.push(`<div class="flex items-start justify-between"><div class="flex items-start space-x-4"><svg class="w-10 h-10"${attr_style(getProviderColor(provider.type))} fill="currentColor" viewBox="0 0 24 24">${html(getProviderIcon(provider.type))}</svg> <div><h3 class="text-lg font-semibold" style="color: rgb(var(--text-primary));">${escape_html(provider.name)}</h3> <p class="text-sm capitalize" style="color: rgb(var(--text-tertiary));">${escape_html(provider.type)}</p> `);
                if (provider.url) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<p class="text-xs mt-1" style="color: rgb(var(--text-tertiary));">${escape_html(provider.url)}</p>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--> `);
                if (provider.connected) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<p class="text-sm flex items-center mt-2 bg-primary-800" style="color: rgb(var(--text-primary));"><svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg> Connected as @${escape_html(provider.username)}</p>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                  $$renderer4.push(`<p class="text-sm mt-2" style="color: rgb(var(--text-tertiary));">Not connected</p>`);
                }
                $$renderer4.push(`<!--]--> `);
                if (provider.is_default) {
                  $$renderer4.push("<!--[-->");
                  $$renderer4.push(`<span class="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-primary-800/10 mt-2" style="color: #0a6522;">Default</span>`);
                } else {
                  $$renderer4.push("<!--[!-->");
                }
                $$renderer4.push(`<!--]--></div></div> <div class="flex flex-col space-y-2">`);
                if (provider.connected) {
                  $$renderer4.push("<!--[-->");
                  Button($$renderer4, {
                    variant: "secondary",
                    size: "sm",
                    onclick: () => handleDisconnect(provider),
                    children: ($$renderer5) => {
                      $$renderer5.push(`<!---->Disconnect`);
                    }
                  });
                } else {
                  $$renderer4.push("<!--[!-->");
                  Button($$renderer4, {
                    size: "sm",
                    onclick: () => handleConnect(provider),
                    children: ($$renderer5) => {
                      $$renderer5.push(`<!---->Connect`);
                    }
                  });
                }
                $$renderer4.push(`<!--]--> `);
                Button($$renderer4, {
                  variant: "ghost",
                  size: "sm",
                  onclick: () => openEditModal(provider),
                  children: ($$renderer5) => {
                    $$renderer5.push(`<!---->Edit`);
                  }
                });
                $$renderer4.push(`<!----> `);
                Button($$renderer4, {
                  variant: "ghost",
                  size: "sm",
                  onclick: () => handleDelete(provider),
                  children: ($$renderer5) => {
                    $$renderer5.push(`<!---->Delete`);
                  }
                });
                $$renderer4.push(`<!----></div></div>`);
              }
            });
            $$renderer3.push(`<!----></div>`);
          }
          $$renderer3.push(`<!--]--></div>`);
        }
        $$renderer3.push(`<!--]-->`);
      }
      $$renderer3.push(`<!--]--></div> `);
      if (showModal) {
        $$renderer3.push("<!--[-->");
        $$renderer3.push(`<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"><div class="rounded-lg border max-w-md w-full max-h-[90vh] overflow-y-auto" style="background-color: rgb(var(--bg-secondary)); border-color: rgb(var(--border-primary));"><div class="p-6"><h3 class="text-xl font-semibold mb-4" style="color: rgb(var(--text-primary));">${escape_html(editingProvider ? "Edit Provider" : "Add Git Provider")}</h3> <form class="space-y-4">`);
        if (!editingProvider) {
          $$renderer3.push("<!--[-->");
          Select($$renderer3, {
            label: "Provider Type",
            options: providerTypeOptions,
            required: true,
            get value() {
              return providerType;
            },
            set value($$value) {
              providerType = $$value;
              $$settled = false;
            }
          });
        } else {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--> `);
        Input($$renderer3, {
          label: "Name",
          placeholder: "e.g., My Company GitHub",
          required: true,
          get value() {
            return providerName;
          },
          set value($$value) {
            providerName = $$value;
            $$settled = false;
          }
        });
        $$renderer3.push(`<!----> `);
        if (providerType === "gitea" || providerType === "gitlab") {
          $$renderer3.push("<!--[-->");
          Input($$renderer3, {
            label: "Instance URL",
            placeholder: "https://git.example.com",
            required: true,
            get value() {
              return providerUrl;
            },
            set value($$value) {
              providerUrl = $$value;
              $$settled = false;
            }
          });
        } else {
          $$renderer3.push("<!--[!-->");
        }
        $$renderer3.push(`<!--]--> `);
        Input($$renderer3, {
          label: "Client ID",
          placeholder: "OAuth Application Client ID",
          required: true,
          get value() {
            return clientId;
          },
          set value($$value) {
            clientId = $$value;
            $$settled = false;
          }
        });
        $$renderer3.push(`<!----> `);
        Input($$renderer3, {
          label: "Client Secret",
          type: "password",
          placeholder: "OAuth Application Client Secret",
          required: true,
          get value() {
            return clientSecret;
          },
          set value($$value) {
            clientSecret = $$value;
            $$settled = false;
          }
        });
        $$renderer3.push(`<!----> <div class="p-3 rounded-lg border" style="background-color: rgb(var(--bg-secondary)); border-color: rgb(var(--border-primary));"><label class="block text-xs font-medium mb-2" style="color: rgb(var(--text-tertiary));">OAuth Callback URL</label> <div class="flex items-center space-x-2"><code class="flex-1 text-xs break-all" style="color: #0a6522;">${escape_html(callbackUrl)}</code> <button type="button" class="px-2 py-1 text-xs rounded transition-colors" style="background-color: rgb(var(--bg-secondary)); color: rgb(var(--text-secondary));" title="Copy to clipboard">Copy</button></div> <p class="mt-2 text-xs" style="color: rgb(var(--text-tertiary));">Use this URL when configuring the OAuth application in your ${escape_html(providerType)} settings.</p></div> <div class="flex items-center"><input id="is-default" type="checkbox"${attr("checked", isDefault, true)} class="h-4 w-4 rounded border-primary-800 bg-primary-800 focus:ring-primary-800"/> <label for="is-default" class="ml-2 text-sm" style="color: rgb(var(--text-secondary));">Set as default provider for ${escape_html(providerType)}</label></div> <div class="flex space-x-3 pt-4">`);
        Button($$renderer3, {
          variant: "ghost",
          onclick: () => showModal = false,
          disabled: modalLoading,
          type: "button",
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->Cancel`);
          }
        });
        $$renderer3.push(`<!----> `);
        Button($$renderer3, {
          type: "submit",
          loading: modalLoading,
          disabled: modalLoading,
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->${escape_html(editingProvider ? "Update" : "Add")}`);
          }
        });
        $$renderer3.push(`<!----></div></form></div></div></div>`);
      } else {
        $$renderer3.push("<!--[!-->");
      }
      $$renderer3.push(`<!--]-->`);
    }
    do {
      $$settled = true;
      $$inner_renderer = $$renderer2.copy();
      $$render_inner($$inner_renderer);
    } while (!$$settled);
    $$renderer2.subsume($$inner_renderer);
  });
}
export {
  _page as default
};
