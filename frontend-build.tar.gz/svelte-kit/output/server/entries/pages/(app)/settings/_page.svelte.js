import { V as head } from "../../../../chunks/index2.js";
import { a as authStore } from "../../../../chunks/auth.svelte.js";
import { a as api } from "../../../../chunks/client2.js";
import { B as Button } from "../../../../chunks/Button.js";
import { C as Card, A as Alert } from "../../../../chunks/Alert.js";
import { e as escape_html } from "../../../../chunks/context.js";
const oauthAPI = {
  // GitHub OAuth
  async getGitHubAuthURL() {
    return api.get("/auth/oauth/github/init");
  },
  async disconnectGitHub() {
    return api.get("/auth/oauth/github/disconnect");
  },
  async listGitHubRepositories() {
    return api.get("/auth/oauth/github/repositories");
  },
  // Gitea OAuth
  async getGiteaAuthURL(giteaURL) {
    return api.post("/auth/oauth/gitea/init", { gitea_url: giteaURL });
  },
  async disconnectGitea() {
    return api.get("/auth/oauth/gitea/disconnect");
  },
  async listGiteaRepositories() {
    return api.get("/auth/oauth/gitea/repositories");
  }
};
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let connecting = false;
    let disconnecting = false;
    let message = "";
    async function connectGitHub() {
      connecting = true;
      try {
        const { url } = await oauthAPI.getGitHubAuthURL();
        window.location.href = url;
      } catch (error) {
        console.error("Failed to connect GitHub:", error);
        message = "Failed to connect GitHub. Please try again.";
        connecting = false;
      }
    }
    async function disconnectGitHub() {
      if (!confirm("Are you sure you want to disconnect GitHub?")) {
        return;
      }
      disconnecting = true;
      try {
        await oauthAPI.disconnectGitHub();
        await authStore.fetchCurrentUser();
        message = "GitHub disconnected successfully";
      } catch (error) {
        console.error("Failed to disconnect GitHub:", error);
        message = "Failed to disconnect GitHub. Please try again.";
      } finally {
        disconnecting = false;
      }
    }
    head($$renderer2, ($$renderer3) => {
      $$renderer3.title(($$renderer4) => {
        $$renderer4.push(`<title>Settings - VPS Panel</title>`);
      });
    });
    $$renderer2.push(`<div class="max-w-4xl mx-auto space-y-6"><div><h1 class="text-3xl font-bold" style="color: rgb(var(--text-primary));">Settings</h1> <p class="mt-1 text-sm" style="color: rgb(var(--text-tertiary));">Manage your account and integrations</p></div> `);
    if (message) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<div>`);
      Alert($$renderer2, {
        variant: "success",
        dismissible: true,
        ondismiss: () => message = "",
        children: ($$renderer3) => {
          $$renderer3.push(`<!---->${escape_html(message)}`);
        }
      });
      $$renderer2.push(`<!----></div>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <div>`);
    Card($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<h2 class="text-lg font-semibold mb-4" style="color: rgb(var(--text-primary));">Profile</h2> <div class="space-y-4"><div><label class="block text-sm font-medium mb-1" style="color: rgb(var(--text-secondary));">Name</label> <p style="color: rgb(var(--text-primary));">${escape_html(authStore.user?.name || "Not set")}</p></div> <div><label class="block text-sm font-medium mb-1" style="color: rgb(var(--text-secondary));">Email</label> <p style="color: rgb(var(--text-primary));">${escape_html(authStore.user?.email)}</p></div> <div><label class="block text-sm font-medium mb-1" style="color: rgb(var(--text-secondary));">Role</label> <p class="capitalize" style="color: rgb(var(--text-primary));">${escape_html(authStore.user?.role)}</p></div></div>`);
      }
    });
    $$renderer2.push(`<!----></div> <div>`);
    Card($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<div class="flex items-center justify-between mb-4"><div><h2 class="text-lg font-semibold" style="color: rgb(var(--text-primary));">Git Providers</h2> <p class="text-sm mt-1" style="color: rgb(var(--text-tertiary));">Manage OAuth connections for GitHub, Gitea, and more</p></div> <a href="/settings/git-providers">`);
        Button($$renderer3, {
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->Manage Providers`);
          }
        });
        $$renderer3.push(`<!----></a></div> <p class="text-sm" style="color: rgb(var(--text-tertiary));">Configure your Git providers to seamlessly import and deploy repositories. You can add multiple accounts for GitHub, self-hosted Gitea instances, and more.</p>`);
      }
    });
    $$renderer2.push(`<!----></div> <div>`);
    Card($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<h2 class="text-lg font-semibold mb-4" style="color: rgb(var(--text-primary));">Connected Accounts (Legacy)</h2> <p class="text-sm mb-6" style="color: rgb(var(--text-tertiary));">⚠️ This section is deprecated. Please use Git Providers above for better management.</p> <div class="flex items-center justify-between p-4 rounded-lg border" style="border-color: rgb(var(--border-primary));"><div class="flex items-center space-x-4"><div class="flex-shrink-0"><svg class="w-10 h-10" style="color: rgb(var(--text-primary));" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0024 12c0-6.63-5.37-12-12-12z"></path></svg></div> <div><h3 class="text-base font-medium" style="color: rgb(var(--text-primary));">GitHub</h3> `);
        if (authStore.user?.github_connected) {
          $$renderer3.push("<!--[-->");
          $$renderer3.push(`<p class="text-sm flex items-center mt-1 bg-primary-800" style="color: rgb(var(--text-primary));"><svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg> Connected as @${escape_html(authStore.user.github_username)}</p>`);
        } else {
          $$renderer3.push("<!--[!-->");
          $$renderer3.push(`<p class="text-sm mt-1" style="color: rgb(var(--text-tertiary));">Not connected</p>`);
        }
        $$renderer3.push(`<!--]--></div></div> <div>`);
        if (authStore.user?.github_connected) {
          $$renderer3.push("<!--[-->");
          Button($$renderer3, {
            variant: "secondary",
            onclick: disconnectGitHub,
            loading: disconnecting,
            disabled: disconnecting,
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->${escape_html(disconnecting ? "Disconnecting..." : "Disconnect")}`);
            }
          });
        } else {
          $$renderer3.push("<!--[!-->");
          Button($$renderer3, {
            onclick: connectGitHub,
            loading: connecting,
            disabled: connecting,
            children: ($$renderer4) => {
              $$renderer4.push(`<!---->${escape_html(connecting ? "Connecting..." : "Connect GitHub")}`);
            }
          });
        }
        $$renderer3.push(`<!--]--></div></div> <div class="flex items-center justify-between p-4 rounded-lg border mt-4 opacity-50" style="border-color: rgb(var(--border-primary));"><div class="flex items-center space-x-4"><div class="flex-shrink-0"><svg class="w-10 h-10 text-orange-500" viewBox="0 0 24 24" fill="currentColor"><path d="M23.955 13.587l-1.342-4.135-2.664-8.189a.455.455 0 0 0-.867 0L16.418 9.45H7.582L4.919 1.263a.455.455 0 0 0-.867 0L1.388 9.452.046 13.587a.924.924 0 0 0 .331 1.023L12 23.054l11.623-8.443a.92.92 0 0 0 .332-1.024"></path></svg></div> <div><h3 class="text-base font-medium" style="color: rgb(var(--text-primary));">GitLab</h3> <p class="text-sm mt-1" style="color: rgb(var(--text-tertiary));">Coming soon</p></div></div> `);
        Button($$renderer3, {
          variant: "secondary",
          disabled: true,
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->Coming Soon`);
          }
        });
        $$renderer3.push(`<!----></div>`);
      }
    });
    $$renderer2.push(`<!----></div> <div>`);
    Card($$renderer2, {
      children: ($$renderer3) => {
        $$renderer3.push(`<h2 class="text-lg font-semibold text-red-500 mb-4">Danger Zone</h2> <div class="space-y-4"><div class="flex items-center justify-between p-4 rounded-lg border border-red-900/50 bg-red-950/20"><div><h3 class="text-base font-medium" style="color: rgb(var(--text-primary));">Delete Account</h3> <p class="text-sm mt-1" style="color: rgb(var(--text-tertiary));">Permanently delete your account and all associated data</p></div> `);
        Button($$renderer3, {
          variant: "secondary",
          disabled: true,
          children: ($$renderer4) => {
            $$renderer4.push(`<!---->Delete Account`);
          }
        });
        $$renderer3.push(`<!----></div></div>`);
      }
    });
    $$renderer2.push(`<!----></div></div>`);
  });
}
export {
  _page as default
};
