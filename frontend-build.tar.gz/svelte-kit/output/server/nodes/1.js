

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.1PvBmLHt.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/DyqB7B_E.js","_app/immutable/chunks/Bsulou8C.js"];
export const stylesheets = [];
export const fonts = [];
