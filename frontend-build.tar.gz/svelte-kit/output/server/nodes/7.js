

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/projects/_id_/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/7.BKjEdcCO.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/DyqB7B_E.js","_app/immutable/chunks/OC4knTux.js","_app/immutable/chunks/ixWHoQ4_.js","_app/immutable/chunks/DAwe-5Le.js","_app/immutable/chunks/Bsulou8C.js","_app/immutable/chunks/C3JlKF8T.js","_app/immutable/chunks/D0CKZVho.js","_app/immutable/chunks/s1flxfBK.js","_app/immutable/chunks/BQju76Fv.js","_app/immutable/chunks/Bda8xOlU.js","_app/immutable/chunks/BJOvl-QZ.js","_app/immutable/chunks/CpS4NJfF.js","_app/immutable/chunks/BPBTRAkx.js","_app/immutable/chunks/Cyvmj67x.js"];
export const stylesheets = [];
export const fonts = [];
