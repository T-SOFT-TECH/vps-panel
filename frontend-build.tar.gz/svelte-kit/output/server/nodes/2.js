

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.DwcD_bDE.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/DyqB7B_E.js","_app/immutable/chunks/OC4knTux.js","_app/immutable/chunks/DZHy8cPl.js","_app/immutable/chunks/DAwe-5Le.js","_app/immutable/chunks/Bsulou8C.js","_app/immutable/chunks/ixWHoQ4_.js","_app/immutable/chunks/Z4jZXzi9.js","_app/immutable/chunks/D0CKZVho.js","_app/immutable/chunks/Br35ouYK.js"];
export const stylesheets = [];
export const fonts = [];
