

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/projects/new/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.DvUPHbz3.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/DyqB7B_E.js","_app/immutable/chunks/OC4knTux.js","_app/immutable/chunks/ixWHoQ4_.js","_app/immutable/chunks/DAwe-5Le.js","_app/immutable/chunks/Bsulou8C.js","_app/immutable/chunks/WzltIs_r.js","_app/immutable/chunks/C3JlKF8T.js","_app/immutable/chunks/W8zpBzUe.js","_app/immutable/chunks/s1flxfBK.js","_app/immutable/chunks/CArYiY8_.js","_app/immutable/chunks/DZHy8cPl.js","_app/immutable/chunks/BPBTRAkx.js","_app/immutable/chunks/Bda8xOlU.js","_app/immutable/chunks/CpS4NJfF.js","_app/immutable/chunks/BJOvl-QZ.js"];
export const stylesheets = [];
export const fonts = [];
