import * as server from '../entries/pages/_page.server.ts.js';

export const index = 3;
export { server };
export const server_id = "src/routes/+page.server.ts";
export const imports = [];
export const stylesheets = [];
export const fonts = [];
