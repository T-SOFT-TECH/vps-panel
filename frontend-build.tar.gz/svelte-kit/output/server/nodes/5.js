

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/(app)/projects/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.DsjU0ZrZ.js","_app/immutable/chunks/DsnmJJEf.js","_app/immutable/chunks/DyqB7B_E.js","_app/immutable/chunks/OC4knTux.js","_app/immutable/chunks/ixWHoQ4_.js","_app/immutable/chunks/DAwe-5Le.js","_app/immutable/chunks/Bsulou8C.js","_app/immutable/chunks/C3JlKF8T.js","_app/immutable/chunks/s1flxfBK.js","_app/immutable/chunks/BJOvl-QZ.js","_app/immutable/chunks/Cyvmj67x.js"];
export const stylesheets = [];
export const fonts = [];
