import "clsx";
import { a as api, b as browser } from "./client2.js";
import { g as goto } from "./client.js";
const authAPI = {
  async checkRegistrationStatus() {
    return api.get("/auth/registration-status", { requiresAuth: false });
  },
  async login(credentials) {
    return api.post("/auth/login", credentials, { requiresAuth: false });
  },
  async register(data) {
    return api.post("/auth/register", data, { requiresAuth: false });
  },
  async getCurrentUser() {
    return api.get("/users/me");
  },
  async updateProfile(data) {
    return api.put("/users/me", data);
  }
};
class AuthStore {
  user = null;
  token = null;
  loading = true;
  constructor() {
  }
  init() {
    const storedToken = localStorage.getItem("token");
    const storedUser = localStorage.getItem("user");
    if (storedToken && storedUser) {
      this.token = storedToken;
      this.user = JSON.parse(storedUser);
    }
    this.loading = false;
  }
  async login(email, password) {
    try {
      const response = await authAPI.login({ email, password });
      this.setAuth(response.token, response.user);
      goto("/dashboard");
      return response;
    } catch (error) {
      console.error("Login failed:", error);
      throw error;
    }
  }
  async register(email, password, name) {
    try {
      const response = await authAPI.register({ email, password, name });
      this.setAuth(response.token, response.user);
      goto("/dashboard");
      return response;
    } catch (error) {
      console.error("Registration failed:", error);
      throw error;
    }
  }
  async fetchCurrentUser() {
    try {
      const user = await authAPI.getCurrentUser();
      this.user = user;
      if (browser) ;
      return user;
    } catch (error) {
      console.error("Failed to fetch user:", error);
      this.logout();
      throw error;
    }
  }
  logout() {
    this.user = null;
    this.token = null;
  }
  setAuth(token, user) {
    this.token = token;
    this.user = user;
  }
  get isAuthenticated() {
    return !!this.token && !!this.user;
  }
}
const authStore = new AuthStore();
export {
  authStore as a
};
