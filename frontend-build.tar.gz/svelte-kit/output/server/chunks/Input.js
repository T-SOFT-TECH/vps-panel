import { X as attr, Y as attr_class, a1 as clsx, a2 as bind_props } from "./index2.js";
import { e as escape_html } from "./context.js";
function Input($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      label,
      type = "text",
      placeholder = "",
      value = "",
      error,
      required = false,
      disabled = false,
      class: className = "",
      id,
      name
    } = $$props;
    const inputId = id || name || `input-${Math.random().toString(36).substr(2, 9)}`;
    const inputClasses = `block w-full rounded-lg border ${error ? "border-red-500 focus:ring-red-500" : "border-zinc-700 focus:ring-green-500"} bg-zinc-900 text-zinc-100 px-3 py-2 focus:outline-none focus:ring-2 disabled:opacity-50 disabled:cursor-not-allowed placeholder:text-zinc-500 ${className}`;
    $$renderer2.push(`<div class="w-full">`);
    if (label) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<label${attr("for", inputId)} class="block text-sm font-medium text-zinc-300 mb-1">${escape_html(label)} `);
      if (required) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="text-red-500">*</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></label>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> <input${attr("type", type)}${attr("placeholder", placeholder)}${attr("required", required, true)}${attr("disabled", disabled, true)}${attr("name", name)}${attr("id", inputId)}${attr("value", value)}${attr_class(clsx(inputClasses))}/> `);
    if (error) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<p class="mt-1 text-sm text-red-600">${escape_html(error)}</p>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { value });
  });
}
export {
  Input as I
};
