import { a as api } from "./client2.js";
import { X as attr, W as ensure_array_like, a2 as bind_props } from "./index2.js";
import { e as escape_html } from "./context.js";
const gitProvidersAPI = {
  // Provider Management
  async getAll() {
    return api.get("/git-providers");
  },
  async getById(id) {
    return api.get(`/git-providers/${id}`);
  },
  async create(data) {
    return api.post("/git-providers", data);
  },
  async update(id, data) {
    return api.put(`/git-providers/${id}`, data);
  },
  async delete(id) {
    return api.delete(`/git-providers/${id}`);
  },
  async disconnect(id) {
    return api.post(`/git-providers/${id}/disconnect`);
  },
  // OAuth Flow
  async initiateOAuth(providerId) {
    const provider = await this.getById(providerId);
    if (provider.type === "github") {
      return api.get(`/auth/oauth/github/init?provider_id=${providerId}`);
    } else if (provider.type === "gitea") {
      return api.get(`/auth/oauth/gitea/init?provider_id=${providerId}`);
    } else {
      throw new Error("Provider type not supported yet");
    }
  },
  // Repository Listing
  async listRepositories(providerId) {
    return api.get(`/git-providers/${providerId}/repositories`);
  }
};
function Select($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let {
      label,
      options,
      value = "",
      error,
      required = false,
      disabled = false,
      class: className = "",
      id,
      name,
      placeholder = "Select an option"
    } = $$props;
    const selectId = id || name || `select-${Math.random().toString(36).substr(2, 9)}`;
    const selectClasses = `block w-full rounded-lg border ${error ? "border-red-500 focus:ring-red-500" : "border-zinc-700 focus:ring-green-500"} bg-zinc-900 text-zinc-100 px-3 py-2 focus:outline-none focus:ring-2 disabled:opacity-50 disabled:cursor-not-allowed ${className}`;
    $$renderer2.push(`<div class="w-full">`);
    if (label) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<label${attr("for", selectId)} class="block text-sm font-medium text-zinc-300 mb-1">${escape_html(label)} `);
      if (required) {
        $$renderer2.push("<!--[-->");
        $$renderer2.push(`<span class="text-red-500">*</span>`);
      } else {
        $$renderer2.push("<!--[!-->");
      }
      $$renderer2.push(`<!--]--></label>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--> `);
    $$renderer2.select(
      {
        required,
        disabled,
        name,
        id: selectId,
        value,
        class: selectClasses
      },
      ($$renderer3) => {
        $$renderer3.option({ value: "", disabled: true }, ($$renderer4) => {
          $$renderer4.push(`${escape_html(placeholder)}`);
        });
        $$renderer3.push(`<!--[-->`);
        const each_array = ensure_array_like(options);
        for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
          let option = each_array[$$index];
          $$renderer3.option({ value: option.value }, ($$renderer4) => {
            $$renderer4.push(`${escape_html(option.label)}`);
          });
        }
        $$renderer3.push(`<!--]-->`);
      }
    );
    $$renderer2.push(` `);
    if (error) {
      $$renderer2.push("<!--[-->");
      $$renderer2.push(`<p class="mt-1 text-sm text-red-600">${escape_html(error)}</p>`);
    } else {
      $$renderer2.push("<!--[!-->");
    }
    $$renderer2.push(`<!--]--></div>`);
    bind_props($$props, { value });
  });
}
export {
  Select as S,
  gitProvidersAPI as g
};
