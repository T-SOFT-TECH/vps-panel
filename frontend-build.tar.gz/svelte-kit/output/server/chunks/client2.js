import { D as DEV } from "./false.js";
import { g as goto } from "./client.js";
const browser = DEV;
const API_BASE_URL = "http://localhost:8080/api/v1";
class APIClient {
  baseURL;
  constructor(baseURL) {
    this.baseURL = baseURL;
  }
  getToken() {
    return null;
  }
  async request(endpoint, options = {}) {
    const { requiresAuth = true, headers = {}, ...fetchOptions } = options;
    const requestHeaders = {
      "Content-Type": "application/json",
      ...headers
    };
    if (requiresAuth) {
      const token = this.getToken();
      if (token) {
        requestHeaders["Authorization"] = `Bearer ${token}`;
      }
    }
    const url = `${this.baseURL}${endpoint}`;
    try {
      const response = await fetch(url, {
        ...fetchOptions,
        headers: requestHeaders,
        credentials: "include"
        // Required for cookies to work cross-origin
      });
      if (response.status === 401) {
        if (browser) ;
        throw new Error("Unauthorized");
      }
      if (!response.ok) {
        const error = await response.json().catch(() => ({ error: "Request failed" }));
        throw new Error(error.error || `HTTP ${response.status}`);
      }
      if (response.status === 204) {
        return {};
      }
      return await response.json();
    } catch (error) {
      console.error("API Error:", error);
      throw error;
    }
  }
  // HTTP Methods
  async get(endpoint, options) {
    return this.request(endpoint, { ...options, method: "GET" });
  }
  async post(endpoint, data, options) {
    return this.request(endpoint, {
      ...options,
      method: "POST",
      body: data ? JSON.stringify(data) : void 0
    });
  }
  async put(endpoint, data, options) {
    return this.request(endpoint, {
      ...options,
      method: "PUT",
      body: data ? JSON.stringify(data) : void 0
    });
  }
  async delete(endpoint, options) {
    return this.request(endpoint, { ...options, method: "DELETE" });
  }
}
const api = new APIClient(API_BASE_URL);
export {
  api as a,
  browser as b
};
